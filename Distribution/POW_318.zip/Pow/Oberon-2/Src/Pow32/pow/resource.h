//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by pow.RC
//
#define IDB_FIMABOUT                    105
#define IDB_INTRO                       106
#define IDD_ABOUTPLUGIN                 301
#define IDD_ABOUTPOW                    301
#define IDD_ABOUTHALL                   302
#define IDD_REPLACEASK                  508
#define IDD_DLLFUNCTIONEDIT             803
#define IDD_DLLARGUMENTSEDIT            804
#define IDD_DDEARGUMENTSEDIT            805
#define IDD_DLLNAME                     1004
#define IDD_DLLFUNCTION                 1005
#define IDD_DLLARGUMENTS                1006
#define IDD_DLLNAMEEDIT                 1007
#define IDD_DDDESERVICE                 1009
#define IDD_DDESERVICEEDIT              1010
#define IDD_DDETOPIC                    1011
#define IDD_DDETOPICEDIT                1012
#define IDD_DDEARGUMENTS                1013
#define IDD_SOURCEDIR                   1018
#define IDD_TOOLADDEXE                  1311
#define IDD_TOOLADDDLL                  1312
#define IDD_TOOLADDDDE                  1313
#define IDD_TOOLMENUENTRY               1314
#define IDD_TOOLSPEEDBUTTON             1315
#define IDD_TOOLICONLIST                1316
#define IDD_TOOLTEXT1NAME               1317
#define IDD_TOOLTEXT2NAME               1318
#define IDD_TOOLTOTOP                   1319
#define IDD_ADDDLLTOOL                  1800
#define IDD_ADDDDETOOL                  1900
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         101
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
