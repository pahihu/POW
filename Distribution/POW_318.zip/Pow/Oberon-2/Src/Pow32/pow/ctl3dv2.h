#ifndef INC_CTL3DV2
#define INC_CTL3DV2

#include <windows.h>

void FAR PASCAL Ctl3dRegister (HINSTANCE);
void FAR PASCAL Ctl3dUnregister (HINSTANCE);
void FAR PASCAL Ctl3dAutoSubclass (HINSTANCE);

#endif

